# P6b_HANDOFF（待 Codex / 用户填写）

- 承接 P6a 实际提交：`[待填写]`
- P6b 实际提交：`[待填写]`
- HealthTask 周期/优先级/栈：`[待填写]`
- ControlTask 监督数据：`wake_count`；停滞判定：`[待填写]`
- IWDG Option Bytes 启动配置（实测/查验）：`[待填写]`
- IWDG Prescaler/Reload：`[待填写]`
- 计算超时及 LSI 不确定性：`[待填写]`
- 唯一喂狗点位置及源码搜索结果：`[待填写]`
- RESET/LOCK/POLICY 输出与 P6a 配合：`[待填写]`
- KEY0/KEY1/CAN 协议未改变：`[待填写]`
- Keil 编译：`NOT RUN / PASS / FAIL + 真实日志`
- T1：`NOT RUN / PASS / FAIL + 操作、输出`
- T2：`NOT RUN / PASS / FAIL + IWDG 复位证明、锁状态`
- T3：`NOT RUN / PASS / FAIL + 运行时间、现象`
- 生产镜像无停喂注入入口：`[待填写]`
- 剩余局限：`[待填写]`
- P6b ACCEPTED：`PENDING`
