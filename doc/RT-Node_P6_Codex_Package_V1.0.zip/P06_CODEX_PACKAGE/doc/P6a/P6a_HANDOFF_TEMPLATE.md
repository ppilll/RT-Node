# P6a_HANDOFF（待 Codex / 用户填写）

- Git 基线：`fc427fa7c0c3a0a3e81b17e75096e1bc00c5f6bf`
- 实际工作提交 / 分支：`[待填写]`
- 新增/修改文件：`[待填写]`
- Flash 安全页：`0x0807F800..0x0807FFFF`；Keil IROM 实际配置：`[待填写]`
- 空白 / INVALID / LOCK / AUTO / MANUAL 行为与代码位置：`[待填写]`
- BootCapture / BootFinalize 调用位置：`[待填写]`
- MODE/Auto LOCAL 门禁位置：`[待填写]`
- KEY0/KEY1/CAN 冻结校验：`[待填写]`
- 本地命令实现：`[待填写]`
- Keil 编译：`NOT RUN / PASS / FAIL + 实际日志`
- 极简接口测试：`NOT RUN / PASS / FAIL + 实际回执`
- 已知限制：IWDG-to-Flash 供电窗口、UART 非认证、Flash 页擦除或写失败诊断等。
- P6a ACCEPTED：`PENDING`（必须由用户依据实际结果批准）
- 是否建议开始 P6b：`PENDING`
